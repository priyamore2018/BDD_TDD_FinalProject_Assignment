"""
features/environment.py
BDD environment hooks — start/stop the Flask test server for Behave.
"""
import tempfile
import sqlite3

from behave import fixture, use_fixture

# ── patch the DB to a temp file before importing the app ─────────────
import service.models as models_module

_tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
_tmp.close()
BDD_DB = _tmp.name
models_module.DATABASE = BDD_DB
models_module.init_db()


@fixture
def flask_client(context, *args, **kwargs):
    """Create a Flask test client and attach it to the Behave context."""
    from service.routes import app
    app.config["TESTING"] = True
    context.client = app.test_client()
    context.app    = app
    yield context.client


def before_all(context):
    use_fixture(flask_client, context)


def before_scenario(context, scenario):
    """Wipe the database before every scenario so tests are independent."""
    conn = sqlite3.connect(BDD_DB)
    conn.execute("DELETE FROM product")
    conn.commit()
    conn.close()
