"""
Product Model for eCommerce Product Catalogue Microservice
"""
import logging
import sqlite3
from enum import Enum
from decimal import Decimal
from typing import Optional

logger = logging.getLogger("flask.app")

DATABASE = "products.db"


def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn


def init_db(db_path=None):
    """Create the database and product table if they do not exist."""
    global DATABASE
    if db_path:
        DATABASE = db_path
    conn = get_db()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS product (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            name        TEXT    NOT NULL,
            description TEXT    NOT NULL,
            price       TEXT    NOT NULL,
            available   INTEGER NOT NULL DEFAULT 1,
            category    TEXT    NOT NULL DEFAULT 'UNKNOWN'
        )
    """)
    conn.commit()
    conn.close()
    logger.info("Database initialised at: %s", DATABASE)


class DataValidationError(Exception):
    """Raised when incoming data fails validation."""
    pass


class Category(Enum):
    """Enumeration of valid Product Categories."""
    UNKNOWN    = 0
    CLOTHS     = 1
    FOOD       = 2
    HOUSEWARES = 3
    AUTOMOTIVE = 4
    TOOLS      = 5


class Product:
    """Represents a single Product in the catalogue."""

    def __init__(self):
        self.id:          Optional[int] = None
        self.name:        str           = ""
        self.description: str           = ""
        self.price:       Decimal       = Decimal("0.00")
        self.available:   bool          = True
        self.category:    Category      = Category.UNKNOWN

    # ------------------------------------------------------------------
    # Instance Methods
    # ------------------------------------------------------------------

    def __repr__(self):
        return f"<Product {self.name} id=[{self.id}]>"

    def create(self):
        """Insert this product into the database."""
        logger.info("Creating product: %s", self.name)
        conn = get_db()
        cursor = conn.execute(
            """INSERT INTO product (name, description, price, available, category)
               VALUES (?, ?, ?, ?, ?)""",
            (self.name, self.description, str(self.price),
             1 if self.available else 0, self.category.name),
        )
        self.id = cursor.lastrowid
        conn.commit()
        conn.close()

    def update(self):
        """Save changes to an existing product back to the database."""
        logger.info("Updating product: %s", self.name)
        if not self.id:
            raise DataValidationError("Update called with empty ID field")
        conn = get_db()
        conn.execute(
            """UPDATE product
               SET name=?, description=?, price=?, available=?, category=?
               WHERE id=?""",
            (self.name, self.description, str(self.price),
             1 if self.available else 0, self.category.name, self.id),
        )
        conn.commit()
        conn.close()

    def delete(self):
        """Remove this product from the database."""
        logger.info("Deleting product: %s", self.name)
        conn = get_db()
        conn.execute("DELETE FROM product WHERE id=?", (self.id,))
        conn.commit()
        conn.close()

    def serialize(self) -> dict:
        """Convert this Product to a plain Python dict (for JSON responses)."""
        return {
            "id":          self.id,
            "name":        self.name,
            "description": self.description,
            "price":       str(self.price),
            "available":   self.available,
            "category":    self.category.name,
        }

    def deserialize(self, data: dict):
        """
        Populate this Product from a dictionary.
        Raises DataValidationError for missing / bad fields.
        """
        try:
            self.name        = data["name"]
            self.description = data["description"]
            self.price       = Decimal(data["price"])
            if isinstance(data["available"], bool):
                self.available = data["available"]
            else:
                raise DataValidationError(
                    "Invalid type for boolean [available]: "
                    + str(type(data["available"]))
                )
            self.category = getattr(Category, data["category"])
        except AttributeError as error:
            raise DataValidationError("Invalid attribute: " + error.args[0]) from error
        except KeyError as error:
            raise DataValidationError("Invalid product: missing field → " + error.args[0]) from error
        except TypeError as error:
            raise DataValidationError(
                "Invalid product: bad or missing data → " + str(error)
            ) from error
        return self

    # ------------------------------------------------------------------
    # Class Methods
    # ------------------------------------------------------------------

    @classmethod
    def _from_row(cls, row) -> "Product":
        p = cls()
        p.id          = row["id"]
        p.name        = row["name"]
        p.description = row["description"]
        p.price       = Decimal(row["price"])
        p.available   = bool(row["available"])
        p.category    = Category[row["category"]]
        return p

    @classmethod
    def all(cls) -> list:
        """Return every product in the database."""
        logger.info("Fetching all products")
        conn = get_db()
        rows = conn.execute("SELECT * FROM product").fetchall()
        conn.close()
        return [cls._from_row(r) for r in rows]

    @classmethod
    def find(cls, product_id: int) -> Optional["Product"]:
        """Find a product by its ID. Returns None if not found."""
        logger.info("Looking up product id=%s", product_id)
        conn = get_db()
        row = conn.execute("SELECT * FROM product WHERE id=?", (product_id,)).fetchone()
        conn.close()
        return cls._from_row(row) if row else None

    @classmethod
    def find_by_name(cls, name: str) -> list:
        """Return all products whose name matches exactly."""
        logger.info("Searching by name: %s", name)
        conn = get_db()
        rows = conn.execute("SELECT * FROM product WHERE name=?", (name,)).fetchall()
        conn.close()
        return [cls._from_row(r) for r in rows]

    @classmethod
    def find_by_price(cls, price) -> list:
        """Return all products with the given price."""
        logger.info("Searching by price: %s", price)
        if isinstance(price, str):
            price = Decimal(price.strip(' "'))
        conn = get_db()
        rows = conn.execute("SELECT * FROM product WHERE price=?", (str(price),)).fetchall()
        conn.close()
        return [cls._from_row(r) for r in rows]

    @classmethod
    def find_by_availability(cls, available: bool = True) -> list:
        """Return all available (or unavailable) products."""
        logger.info("Searching by availability: %s", available)
        conn = get_db()
        rows = conn.execute(
            "SELECT * FROM product WHERE available=?", (1 if available else 0,)
        ).fetchall()
        conn.close()
        return [cls._from_row(r) for r in rows]

    @classmethod
    def find_by_category(cls, category: Category = Category.UNKNOWN) -> list:
        """Return all products in a given category."""
        logger.info("Searching by category: %s", category.name)
        conn = get_db()
        rows = conn.execute(
            "SELECT * FROM product WHERE category=?", (category.name,)
        ).fetchall()
        conn.close()
        return [cls._from_row(r) for r in rows]
